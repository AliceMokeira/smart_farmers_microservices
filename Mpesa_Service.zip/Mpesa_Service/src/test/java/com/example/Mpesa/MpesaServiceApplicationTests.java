package com.example.Mpesa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MpesaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
