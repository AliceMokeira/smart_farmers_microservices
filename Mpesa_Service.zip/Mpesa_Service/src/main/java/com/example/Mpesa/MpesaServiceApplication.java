package com.example.Mpesa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MpesaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MpesaServiceApplication.class, args);
	}

}
